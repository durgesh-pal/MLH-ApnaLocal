import React, { useState } from 'react';
import { Outlet, Link, useLocation } from 'react-router-dom';
import { Home, Search, Calendar, FileText, Users, User, LogOut, Sparkles, Mail, CheckCircle2, AlertCircle } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { auth } from '../../lib/firebase';
import { signOut, sendEmailVerification } from 'firebase/auth';
import FloatingChatWidget from '../FloatingChatWidget';

const Layout: React.FC = () => {
  const { user, firebaseUser, isAdmin, isEmailVerified } = useAuth();
  const location = useLocation();
  const [resendingEmail, setResendingEmail] = useState(false);
  const [emailSent, setEmailSent] = useState(false);

  const navItems = [
    { label: 'Home', icon: Home, path: '/dashboard', roles: ['customer', 'provider', 'admin'] },
    { label: 'Services', icon: Search, path: '/search', roles: ['customer', 'provider', 'admin'] },
    { label: 'AI Chat', icon: Sparkles, path: '/ai', roles: ['customer', 'provider', 'admin'] },
    { label: 'Bookings', icon: Calendar, path: '/bookings', roles: ['customer', 'provider', 'admin'] },
    { label: 'Reports', icon: FileText, path: '/reports', roles: ['customer', 'provider', 'admin'] },
    { label: 'Community', icon: Users, path: '/community', roles: ['customer', 'provider', 'admin'] },
  ];

  if (isAdmin) {
    navItems.push({ label: 'Admin Portal', icon: User, path: '/admin', roles: ['admin'] });
  }

  const handleLogout = () => signOut(auth);

  const handleResendVerification = async () => {
    if (!firebaseUser) return;
    setResendingEmail(true);
    try {
      await sendEmailVerification(firebaseUser);
      setEmailSent(true);
      setTimeout(() => setEmailSent(false), 5000);
    } catch (err) {
      console.error("Error sending verification email:", err);
    } finally {
      setResendingEmail(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between gap-8">
          <Link to="/" className="text-xl font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0 flex items-center gap-2">
            ApnaLocal
            {isAdmin && <span className="bg-slate-900 text-white text-[10px] font-bold px-2 py-0.5 rounded-full uppercase">Admin</span>}
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
            {navItems.map((item) => (
              <Link 
                key={item.path} 
                to={item.path}
                className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 ${location.pathname === item.path ? 'text-slate-900 font-bold underline' : ''}`}
              >
                {item.label}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-3 shrink-0">
            {user ? (
              <div className="flex items-center gap-4">
                <span className="hidden sm:inline text-sm font-medium text-slate-700">
                  Hi, {user.displayName?.split(' ')[0]}
                </span>
                <button 
                  onClick={handleLogout} 
                  className="p-2 text-slate-600 hover:text-slate-900 transition-colors"
                  title="Sign Out"
                >
                  <LogOut size={20} />
                </button>
              </div>
            ) : (
              <Link to="/login" className="btn-primary">Login</Link>
            )}
          </div>
        </div>
      </header>

      {/* Email Verification Banner */}
      {firebaseUser && !isEmailVerified && (
        <div className="bg-amber-500 text-slate-900 px-4 py-2 text-xs font-bold flex flex-wrap items-center justify-between gap-2 z-20">
          <div className="flex items-center gap-2">
            <AlertCircle size={16} />
            <span>Email Verification Required: Please verify your email address ({firebaseUser.email}) for full account security.</span>
          </div>
          <button 
            onClick={handleResendVerification}
            disabled={resendingEmail || emailSent}
            className="bg-slate-900 text-white px-3 py-1 rounded-lg hover:bg-slate-800 transition-colors disabled:opacity-50 text-[11px]"
          >
            {emailSent ? 'Verification Email Sent!' : (resendingEmail ? 'Sending...' : 'Resend Verification Link')}
          </button>
        </div>
      )}

      {/* Main Content */}
      <main className="flex-1 max-w-7xl mx-auto w-full px-4 py-6 pb-24 md:pb-6">
        <Outlet />
      </main>

      {/* Floating Gemini Chatbot Widget */}
      <FloatingChatWidget />

      {/* Mobile Bottom Nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 h-16 flex items-center justify-around z-30">
        {navItems.map((item) => (
          <Link 
            key={item.path} 
            to={item.path}
            className={`flex flex-col items-center gap-1 p-2 ${location.pathname === item.path ? 'text-slate-900' : 'text-slate-500'}`}
          >
            <item.icon size={20} />
            <span className="text-[10px] font-medium">{item.label}</span>
          </Link>
        ))}
      </nav>
    </div>
  );
};

export default Layout;
