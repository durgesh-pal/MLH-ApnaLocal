import React from 'react';
import { Link } from 'react-router-dom';
import { Search, Sparkles, MapPin, Calendar, Clock, ChevronRight, Users } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { useGeolocation } from '../../hooks/useGeolocation';

const categories = [
  { name: 'Plumbing', icon: '🚰' },
  { name: 'Electrician', icon: '⚡' },
  { name: 'Cleaning', icon: '🧹' },
  { name: 'Carpentry', icon: '🪚' },
  { name: 'AC Repair', icon: '❄️' },
  { name: 'Tutor', icon: '📚' },
  { name: 'Beauty', icon: '💅' },
  { name: 'More', icon: '➕' },
];

const CustomerDashboard: React.FC = () => {
  const { user } = useAuth();
  const { nearestLocality, loading: geoLoading } = useGeolocation();

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      {/* Search & Location */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Hello, {user?.displayName?.split(' ')[0]}!</h1>
          <div className="flex items-center text-slate-500 text-sm mt-1">
            <MapPin size={14} className="mr-1" />
            <span>{geoLoading ? 'Detecting location...' : nearestLocality || 'Jaunpur, Uttar Pradesh'}</span>
          </div>
        </div>
        <div className="relative flex-1 max-w-md">
          <Link to={`/search${nearestLocality ? `?locality=${nearestLocality}` : ''}`} className="block">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <div className="w-full h-12 pl-10 pr-4 bg-white border border-slate-200 rounded-xl flex items-center text-slate-400 shadow-sm cursor-text">
              Aapko kya chahiye?
            </div>
          </Link>
        </div>
      </div>

      {/* AI Assistant Banner */}
      <section className="relative overflow-hidden bg-slate-900 rounded-2xl p-6 md:p-8 text-white shadow-xl group">
        <div className="absolute top-0 right-0 w-64 h-64 bg-slate-800 rounded-full -mr-20 -mt-20 opacity-50 blur-3xl transition-transform group-hover:scale-110" />
        <div className="relative z-10 md:flex items-center justify-between gap-8">
          <div className="max-w-xl">
            <div className="flex items-center gap-2 text-slate-300 text-sm font-semibold mb-3">
              <Sparkles size={16} className="text-amber-400" />
              <span>AI POWERED ASSISTANT</span>
            </div>
            <h2 className="text-2xl md:text-3xl font-bold mb-4">Describe your problem, let AI find the solution.</h2>
            <p className="text-slate-300 mb-6 leading-relaxed">
              "Mere kitchen ka nal leak kar raha hai aur mujhe aaj shaam plumber chahiye."
              Describe in Hindi, English or Hinglish.
            </p>
            <Link to="/ai" className="btn-primary bg-white text-slate-900 hover:bg-slate-100 px-6 flex items-center justify-center w-fit">
              Ask AI Assistant
            </Link>
          </div>
          <div className="hidden lg:block">
            <div className="w-48 h-48 bg-white/10 rounded-full flex items-center justify-center backdrop-blur-sm border border-white/20">
              <Sparkles size={64} className="text-white animate-pulse" />
            </div>
          </div>
        </div>
      </section>

      {/* Categories Grid */}
      <section>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-bold text-slate-900">What do you need?</h2>
          <Link to="/search" className="text-sm font-semibold text-slate-900 flex items-center hover:underline">
            View All <ChevronRight size={16} />
          </Link>
        </div>
        <div className="grid grid-cols-4 md:grid-cols-8 gap-4">
          {categories.map((cat, i) => (
            <Link 
              key={i} 
              to={`/search?category=${cat.name}`}
              className="flex flex-col items-center gap-2 p-4 bg-white border border-slate-100 rounded-2xl hover:border-slate-900 hover:shadow-md transition-all group"
            >
              <span className="text-2xl group-hover:scale-110 transition-transform">{cat.icon}</span>
              <span className="text-[11px] font-semibold text-slate-600 text-center">{cat.name}</span>
            </Link>
          ))}
        </div>
      </section>

      {/* Active Bookings (Empty State) */}
      <section>
        <h2 className="text-lg font-bold text-slate-900 mb-6">Active Bookings</h2>
        <div className="card p-12 text-center">
          <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4 text-slate-400">
            <Calendar size={28} />
          </div>
          <h3 className="font-bold text-slate-900 mb-2">No active bookings</h3>
          <p className="text-slate-500 text-sm max-w-xs mx-auto mb-6">
            You don't have any upcoming services scheduled. Browse categories to get started.
          </p>
          <Link to="/search" className="btn-secondary inline-flex items-center">
            Find a Service
          </Link>
        </div>
      </section>

      {/* Community Help */}
      <section className="bg-amber-50 rounded-2xl p-6 border border-amber-100">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-xl bg-white flex items-center justify-center text-amber-600 shrink-0 shadow-sm">
            <Users size={24} />
          </div>
          <div className="flex-1">
            <h2 className="text-lg font-bold text-slate-900 mb-1">Community Assistance</h2>
            <p className="text-slate-600 text-sm mb-4">
              Need non-emergency help from your neighbors? Or found something? Post it on the community wall.
            </p>
            <Link to="/community" className="text-amber-700 font-bold text-sm flex items-center hover:underline">
              Go to Community <ChevronRight size={16} />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default CustomerDashboard;
