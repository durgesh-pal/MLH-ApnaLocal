import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { User, Briefcase, ChevronRight } from 'lucide-react';
import { UserRole } from '../types';

const RegisterPage: React.FC = () => {
  const navigate = useNavigate();

  const handleRoleSelect = (role: UserRole) => {
    navigate(`/login?role=${role}`);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
      <div className="max-w-2xl w-full">
        <div className="text-center mb-12">
          <Link to="/" className="text-3xl font-bold text-slate-900">ApnaLocal</Link>
          <h2 className="text-2xl font-bold mt-4">Choose Your Role</h2>
          <p className="text-slate-500 mt-2">How would you like to use ApnaLocal?</p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <button 
            onClick={() => handleRoleSelect('customer')}
            className="group card p-8 text-left hover:border-slate-900 transition-all"
          >
            <div className="w-14 h-14 rounded-2xl bg-slate-100 flex items-center justify-center text-slate-900 mb-6 group-hover:bg-slate-900 group-hover:text-white transition-colors">
              <User size={32} />
            </div>
            <h3 className="text-xl font-bold text-slate-900 mb-2">I am a Customer</h3>
            <p className="text-slate-500 mb-8">I want to find and book local service providers in my area.</p>
            <div className="flex items-center text-slate-900 font-semibold">
              Get Started <ChevronRight size={18} className="ml-1" />
            </div>
          </button>

          <button 
            onClick={() => handleRoleSelect('provider')}
            className="group card p-8 text-left hover:border-slate-900 transition-all"
          >
            <div className="w-14 h-14 rounded-2xl bg-slate-100 flex items-center justify-center text-slate-900 mb-6 group-hover:bg-slate-900 group-hover:text-white transition-colors">
              <Briefcase size={32} />
            </div>
            <h3 className="text-xl font-bold text-slate-900 mb-2">I am a Provider</h3>
            <p className="text-slate-500 mb-8">I want to offer my services and grow my business locally.</p>
            <div className="flex items-center text-slate-900 font-semibold">
              Join as Provider <ChevronRight size={18} className="ml-1" />
            </div>
          </button>
        </div>

        <p className="text-center text-slate-500 text-sm mt-12">
          Already have an account? {' '}
          <Link to="/login" className="text-slate-900 font-semibold hover:underline">
            Sign In
          </Link>
        </p>
      </div>
    </div>
  );
};

export default RegisterPage;
