import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowRight, Star, Shield, Clock, MapPin, Search, MessageSquare } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { collection, query, getDocs, orderBy, limit, where } from 'firebase/firestore';
import { db } from '../lib/firebase';
import LocationPicker from '../components/LocationPicker';

const LandingPage: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [categories, setCategories] = useState<any[]>([]);
  const [selectedLocality, setSelectedLocality] = useState('');
  const [recentRequests, setRecentRequests] = useState<any[]>([]);

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const q = query(collection(db, 'serviceCategories'), orderBy('name'));
        const snapshot = await getDocs(q);
        setCategories(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      } catch (err) {
        console.error("Error fetching categories:", err);
      }
    };
    fetchCategories();
  }, []);

  useEffect(() => {
    const fetchRequests = async () => {
      try {
        let q;
        if (selectedLocality) {
          q = query(
            collection(db, 'communityPosts'), 
            where('locality', '==', selectedLocality),
            orderBy('createdAt', 'desc'), 
            limit(3)
          );
        } else {
          q = query(
            collection(db, 'communityPosts'), 
            orderBy('createdAt', 'desc'), 
            limit(3)
          );
        }
        const snapshot = await getDocs(q);
        setRecentRequests(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      } catch (err) {
        console.error("Error fetching recent requests:", err);
      }
    };
    fetchRequests();
  }, [selectedLocality]);

  const handleSearchClick = () => {
    const params = new URLSearchParams();
    if (selectedLocality) params.set('locality', selectedLocality);
    navigate(`/search?${params.toString()}`);
  };

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative h-[650px] flex items-center justify-center overflow-hidden">
        <img 
          src="/src/assets/images/hero_jaunpur_1792741417091.jpg" 
          alt="Jaunpur city" 
          className="absolute inset-0 w-full h-full object-cover scale-105"
        />
        <div className="absolute inset-0 bg-slate-900/50 backdrop-blur-[1px]" />
        
        <div className="relative z-10 max-w-4xl mx-auto px-4 text-center text-white">
          <div className="mb-8 flex justify-center gap-2">
            <LocationPicker 
              selectedLocality={selectedLocality} 
              onLocalityChange={setSelectedLocality} 
            />
          </div>
          
          <h1 className="text-4xl md:text-7xl font-extrabold mb-6 tracking-tight leading-tight">
            Har Zaroorat Ka <br/>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-emerald-400">
              Local Solution.
            </span>
          </h1>
          <p className="text-lg md:text-xl mb-10 text-slate-200 font-medium max-w-2xl mx-auto">
            Find trusted local service providers and community support across Jaunpur. 
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button 
              onClick={handleSearchClick}
              className="btn-primary bg-white text-slate-900 hover:bg-slate-100 h-14 px-10 flex items-center justify-center text-lg rounded-full font-bold shadow-xl shadow-white/10"
            >
              <Search className="mr-2" size={20} /> Find Providers
            </button>
            <Link 
              to="/register?role=provider" 
              className="btn-secondary bg-transparent border-white/30 text-white hover:bg-white/10 h-14 px-10 flex items-center justify-center text-lg rounded-full font-bold backdrop-blur-sm"
            >
              Join as Provider
            </Link>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 bg-white border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { label: 'Local Providers', value: '500+' },
              { label: 'Happy Customers', value: '2k+' },
              { label: 'Services Offered', value: '50+' },
              { label: 'Primary Area', value: selectedLocality || 'Jaunpur' },
            ].map((stat, i) => (
              <div key={i} className="text-center">
                <div className="text-3xl font-bold text-slate-900 mb-1">{stat.value}</div>
                <div className="text-sm text-slate-400 font-medium uppercase tracking-wider">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Community Needs Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4">
            <div>
              <h2 className="text-3xl font-bold text-slate-900 mb-2">Nearby Community Requests</h2>
              <p className="text-slate-500">
                {selectedLocality 
                  ? `Active requests from people in ${selectedLocality}.` 
                  : "Latest requests from all across Jaunpur."}
              </p>
            </div>
            <Link to="/community" className="btn-secondary flex items-center gap-2 w-fit">
              View Community Wall <MessageSquare size={18} />
            </Link>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {recentRequests.length > 0 ? (
              recentRequests.map((request, i) => (
                <div key={i} className="card p-6 flex flex-col h-full hover:border-slate-300 transition-all">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-400 mb-4 uppercase tracking-tighter">
                    <MapPin size={12} />
                    {request.locality}
                  </div>
                  <h3 className="text-lg font-bold text-slate-900 mb-2 line-clamp-2">{request.title}</h3>
                  <p className="text-slate-600 text-sm mb-6 line-clamp-3 flex-1">{request.description}</p>
                  <div className="flex items-center justify-between pt-4 border-t border-slate-50">
                    <span className="text-emerald-600 font-bold text-sm">₹{request.budget || 'Open'}</span>
                    <Link to={`/community/${request.id}`} className="text-slate-900 font-bold text-sm hover:underline flex items-center gap-1">
                      Help Out <ArrowRight size={14} />
                    </Link>
                  </div>
                </div>
              ))
            ) : (
              <div className="col-span-3 py-20 text-center bg-slate-50 rounded-3xl border-2 border-dashed border-slate-200">
                <MessageSquare className="mx-auto text-slate-300 mb-4" size={48} />
                <h3 className="text-xl font-bold text-slate-900 mb-2">No requests in this area yet</h3>
                <p className="text-slate-500 mb-6">Be the first to post a request or explore other areas.</p>
                <Link to="/community" className="btn-primary">Post a Request</Link>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-20 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between mb-12">
            <div>
              <h2 className="text-3xl font-bold text-slate-900 mb-2">Popular Categories</h2>
              <p className="text-slate-500">Explore the most requested services in {selectedLocality || 'Jaunpur'}.</p>
            </div>
            <Link 
              to={selectedLocality ? `/search?locality=${selectedLocality}` : "/search"} 
              className="hidden sm:flex items-center text-slate-900 font-semibold hover:underline"
            >
              View All <ArrowRight className="ml-2" size={16} />
            </Link>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {categories.map((cat, i) => (
              <Link 
                key={i} 
                to={`/search?category=${cat.name}${selectedLocality ? `&locality=${selectedLocality}` : ''}`} 
                className="group card hover:shadow-md transition-all overflow-hidden border-none"
              >
                <div className="aspect-[4/3] bg-slate-200 relative">
                  {cat.image ? (
                    <img src={cat.image} alt={cat.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-slate-100 to-slate-200">
                      <span className="text-4xl group-hover:scale-110 transition-transform">{cat.icon}</span>
                    </div>
                  )}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
                <div className="p-4 flex items-center justify-between bg-white">
                  <span className="font-semibold text-slate-900">{cat.name}</span>
                  <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center group-hover:bg-slate-900 group-hover:text-white transition-colors">
                    <ArrowRight size={14} />
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 grid md:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-3xl font-bold text-slate-900 mb-6">Why ApnaLocal?</h2>
            <div className="space-y-6">
              {[
                { title: 'Verified Professionals', desc: 'Every provider undergoes a thorough verification process.', icon: Shield },
                { title: 'Instant Booking', desc: 'Book services in seconds with our AI-assisted flow.', icon: Clock },
                { title: 'Local Support', desc: 'Dedicated to serving the community of Jaunpur.', icon: MapPin },
                { title: 'AI Matching', desc: 'Smart algorithms to find the perfect match for your needs.', icon: Search },
              ].map((item, i) => (
                <div key={i} className="flex gap-4">
                  <div className="w-12 h-12 rounded-xl bg-slate-50 flex items-center justify-center text-slate-900 shrink-0">
                    <item.icon size={24} />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900 mb-1">{item.title}</h3>
                    <p className="text-slate-600 leading-relaxed">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="rounded-3xl overflow-hidden shadow-2xl relative group">
            <img 
              src="/src/assets/images/community_help_1792741418066.jpg" 
              alt="Community help" 
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" 
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 to-transparent" />
            <div className="absolute bottom-8 left-8 right-8 text-white">
              <p className="text-2xl font-bold mb-2">"ApnaLocal helped me find a plumber in minutes when I was in Olandganj."</p>
              <p className="text-slate-300 font-medium">— Local Resident</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-white py-16 mt-auto">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-12 mb-12">
            <div className="col-span-2">
              <h3 className="text-2xl font-bold mb-4">ApnaLocal</h3>
              <p className="text-slate-400 mb-6 max-w-sm">
                Hyperlocal services and community assistance platform for Jaunpur. Har Zaroorat Ka Local Solution.
              </p>
            </div>
            <div>
              <h4 className="font-bold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-slate-400">
                <li><Link to="/search">Find Services</Link></li>
                <li><Link to="/register?role=provider">Become a Provider</Link></li>
                <li><Link to="/community">Community</Link></li>
                <li><Link to="/about">About Us</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Support</h4>
              <ul className="space-y-2 text-slate-400">
                <li><Link to="/help">Help Center</Link></li>
                <li><Link to="/privacy">Privacy Policy</Link></li>
                <li><Link to="/terms">Terms of Service</Link></li>
                <li><Link to="/contact">Contact Us</Link></li>
              </ul>
            </div>
          </div>
          <div className="pt-8 border-t border-slate-800 text-center text-slate-500 text-sm">
            © 2026 ApnaLocal. All rights reserved. Made for Jaunpur, UP.
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;

