import React, { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { Search as SearchIcon, Filter, Star, MapPin, ChevronRight, ShieldCheck, X, Map as MapIcon, List, AlertTriangle, Crosshair } from 'lucide-react';
import { collection, query, getDocs, doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { JAUNPUR_LOCALITIES } from '../lib/localities';
import ProviderMap from '../components/ProviderMap';
import { useGeolocation } from '../hooks/useGeolocation';

const ServiceSearch: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const categoryParam = searchParams.get('category') || '';
  const localityParam = searchParams.get('locality') || '';
  
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState(categoryParam);
  const [selectedLocality, setSelectedLocality] = useState(localityParam);
  const [providers, setProviders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<'list' | 'map'>('list');
  const { nearestLocality, loading: geoLoading } = useGeolocation();

  useEffect(() => {
    if (nearestLocality && !localityParam) {
        setSelectedLocality(nearestLocality);
        updateFilters('locality', nearestLocality);
    }
  }, [nearestLocality]);

  useEffect(() => {
    setSelectedCategory(searchParams.get('category') || '');
    setSelectedLocality(searchParams.get('locality') || '');
  }, [searchParams]);

  useEffect(() => {
    const fetchAndAutoSeedProviders = async () => {
      setLoading(true);
      try {
        let loadedProviders: any[] = [];
        
        try {
          const q = query(collection(db, 'providerProfiles'));
          const snapshot = await getDocs(q);
          if (!snapshot.empty) {
            loadedProviders = snapshot.docs.map(docSnap => {
              const d = docSnap.data();
              return {
                id: docSnap.id,
                ...d,
                businessName: d.businessName || d.display_name || 'Provider',
                name: d.name || d.sample_name || 'Jaunpur Provider',
                category: d.category || 'Service',
                locality: d.locality || 'Jaunpur',
                price: d.price || d.price_guidance || 'Contact for price',
                isDemo: d.isDemo || d.profile_type === 'DEMO_ONLY' || d.is_real_provider === false
              };
            });
          }
        } catch (dbErr) {
          console.warn("Firestore query fallback to dataset:", dbErr);
        }

        // If Firestore is empty or has very few records, fetch and auto-seed the 448 demo records dataset
        if (loadedProviders.length < 100) {
          try {
            const seedRes = await fetch('/assets/aistudio/apnalocal_jaunpur_demo_providers_448_0ba92592.json');
            const seedData = await seedRes.json();
            
            if (seedData && Array.isArray(seedData.providers)) {
              const mappedSeed = seedData.providers.map((p: any) => ({
                id: p.provider_id,
                ...p,
                businessName: p.display_name,
                name: p.sample_name,
                price: p.price_guidance,
                isDemo: true,
                is_real_provider: false
              }));

              // Merge seed data with any real existing Firestore docs (avoiding duplicate IDs)
              const existingIds = new Set(loadedProviders.map(p => p.id || p.provider_id));
              const missingSeed = mappedSeed.filter((p: any) => !existingIds.has(p.id));
              loadedProviders = [...loadedProviders, ...missingSeed];

              // Background auto-seed into Firestore asynchronously so it persists
              setTimeout(async () => {
                for (const p of seedData.providers) {
                  try {
                    await setDoc(doc(db, 'providerProfiles', p.provider_id), {
                      ...p,
                      isDemo: true,
                      is_real_provider: false,
                      updatedAt: serverTimestamp()
                    }, { merge: true });
                  } catch (e) {
                    // Ignore single doc errors
                  }
                }
              }, 100);
            }
          } catch (seedErr) {
            console.error("Error loading demo dataset file:", seedErr);
          }
        }

        setProviders(loadedProviders);
      } catch (err) {
        console.error("Error in fetchAndAutoSeedProviders:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchAndAutoSeedProviders();
  }, []);

  const updateFilters = (key: string, value: string) => {
    const newParams = new URLSearchParams(searchParams);
    if (value) {
      newParams.set(key, value);
    } else {
      newParams.delete(key);
    }
    setSearchParams(newParams);
  };

  const formatSkillsString = (skills: any): string => {
    if (!skills) return '';
    if (Array.isArray(skills)) return skills.join(' ');
    if (typeof skills === 'string') return skills;
    return String(skills);
  };

  const cleanPrice = (priceStr?: string): string => {
    if (!priceStr) return 'Rs. 150 (Visit)';
    return priceStr
      .replace(/\u20B9/g, 'Rs. ')
      .replace(/[\uFFFD\u0080-\u009F\u0000-\u001F]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  };

  const normalizeTerm = (term: string): string => {
    const t = (term || '').toLowerCase().trim();
    if (!t) return '';
    if (t.includes('clean') || t.includes('sweep') || t.includes('safai')) return 'cleaning';
    if (t.includes('beaut') || t.includes('buety') || t.includes('salon') || t.includes('parlor')) return 'beauty';
    if (t.includes('mechan') || t.includes('machanic') || t.includes('bike') || t.includes('car')) return 'mechanic';
    if (t.includes('ac') || t.includes('cool')) return 'ac repair';
    if (t.includes('plumb') || t.includes('pipe') || t.includes('tap') || t.includes('nal')) return 'plumber';
    if (t.includes('electr') || t.includes('wire') || t.includes('bijli')) return 'electrician';
    if (t.includes('carpent') || t.includes('wood') || t.includes('furniture')) return 'carpenter';
    if (t.includes('tutor') || t.includes('teach') || t.includes('twitt') || t.includes('study')) return 'tutor';
    return t;
  };

  const filteredProviders = providers.filter(p => {
    const skillsStr = formatSkillsString(p.skills).toLowerCase();
    const categoryStr = (p.category || '').toLowerCase();
    const searchLower = searchTerm.toLowerCase().trim();
    const searchNormalized = normalizeTerm(searchTerm);

    // Search term matching (fuzzy & synonym aware)
    const matchesSearch = !searchLower ? true : (
      (p.businessName || '').toLowerCase().includes(searchLower) || 
      (p.name || '').toLowerCase().includes(searchLower) ||
      skillsStr.includes(searchLower) ||
      categoryStr.includes(searchLower) ||
      (searchNormalized && categoryStr.includes(searchNormalized)) ||
      (p.locality || '').toLowerCase().includes(searchLower)
    );

    // Category filter matching
    const catLower = selectedCategory.toLowerCase().trim();
    const catNormalized = normalizeTerm(selectedCategory);
    const matchesCategory = !selectedCategory ? true : (
      categoryStr.includes(catLower) ||
      skillsStr.includes(catLower) ||
      (catNormalized && categoryStr.includes(catNormalized)) ||
      (p.category_id || '').toLowerCase() === catLower
    );

    // Locality filter matching (fuzzy)
    const locLower = selectedLocality.toLowerCase().trim();
    const pLocality = (p.locality || '').toLowerCase();
    const pServiceArea = (p.service_area || '').toLowerCase();

    const matchesLocality = !selectedLocality ? true : (
      pLocality.includes(locLower) ||
      pServiceArea.includes(locLower) ||
      locLower.includes(pLocality) ||
      (p.locality_id || '').toLowerCase() === locLower
    );

    return matchesSearch && matchesCategory && matchesLocality;
  });

  const clearFilters = () => {
    setSearchTerm('');
    setSelectedCategory('');
    setSelectedLocality('');
    setSearchParams({});
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto px-4 py-8">
      {/* Search Header */}
      <div className="bg-white card p-6 shadow-sm">
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="relative flex-1">
            <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
            <input 
              type="text" 
              placeholder="Search by name, skills (e.g. Electrician, Plumber, Cleaner, Beauty, Mechanic, AC Repair)..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full h-12 pl-12 pr-4 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-slate-900 transition-all font-medium"
            />
          </div>
          <div className="grid grid-cols-2 sm:flex gap-2">
            <select 
              value={selectedCategory}
              onChange={(e) => {
                setSelectedCategory(e.target.value);
                updateFilters('category', e.target.value);
              }}
              className="h-12 px-4 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-slate-900 font-medium appearance-none min-w-[140px]"
            >
              <option value="">All Categories</option>
              <option value="Electrician">Electrician</option>
              <option value="Plumber">Plumber</option>
              <option value="Mechanic">Mechanic</option>
              <option value="AC Repair">AC Repair</option>
              <option value="Carpenter">Carpenter</option>
              <option value="Cleaning">Cleaning</option>
              <option value="Tutor">Tutor</option>
              <option value="Beauty">Beauty</option>
            </select>

            <select 
              value={selectedLocality}
              onChange={(e) => {
                setSelectedLocality(e.target.value);
                updateFilters('locality', e.target.value);
              }}
              className="h-12 px-4 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-slate-900 font-medium appearance-none min-w-[140px]"
            >
              <option value="">All Jaunpur (14 Localities)</option>
              {JAUNPUR_LOCALITIES.map(loc => (
                <option key={loc.name} value={loc.name}>{loc.name}</option>
              ))}
            </select>

            {(selectedCategory || selectedLocality || searchTerm) && (
              <button 
                onClick={clearFilters}
                className="btn-secondary h-12 px-4 flex items-center gap-2 border-red-100 text-red-600 hover:bg-red-50"
                title="Clear All Filters"
              >
                <X size={18} />
                <span className="hidden sm:inline">Clear</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Results Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-slate-900">
          {loading ? 'Searching Jaunpur Providers...' : (
            <>
              {filteredProviders.length} {filteredProviders.length === 1 ? 'Provider' : 'Providers'} found
              {selectedLocality && <span className="text-slate-400 font-normal ml-2">in {selectedLocality}</span>}
              {selectedCategory && <span className="text-slate-400 font-normal ml-2">for {selectedCategory}</span>}
            </>
          )}
        </h2>
        <div className="flex bg-slate-100 p-1 rounded-xl">
          <button 
            onClick={() => setViewMode('list')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-bold transition-all ${viewMode === 'list' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
          >
            <List size={18} />
            List
          </button>
          <button 
            onClick={() => setViewMode('map')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-bold transition-all ${viewMode === 'map' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
          >
            <MapIcon size={18} />
            Map
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="min-h-[500px]">
        {loading ? (
          <div className="grid gap-6">
            {Array(3).fill(0).map((_, i) => (
              <div key={i} className="card p-6 h-48 animate-pulse bg-slate-50" />
            ))}
          </div>
        ) : viewMode === 'map' ? (
          <div className="h-[600px] w-full">
            <ProviderMap providers={filteredProviders} selectedLocality={selectedLocality} />
          </div>
        ) : (
          <div className="grid gap-6">
            {filteredProviders.length > 0 ? (
              filteredProviders.map((provider) => (
                <Link 
                  key={provider.id || provider.provider_id} 
                  to={`/provider/${provider.provider_id || provider.id}`}
                  className="card p-4 md:p-6 hover:shadow-lg transition-all group flex flex-col md:flex-row gap-6 border-slate-100 bg-white"
                >
                  <div className="w-full md:w-48 aspect-[4/3] md:aspect-square rounded-2xl overflow-hidden bg-slate-100 shrink-0 flex items-center justify-center">
                    <img 
                      src={provider.photo || `https://api.dicebear.com/7.x/avataaars/svg?seed=${provider.businessName}`} 
                      alt={provider.businessName} 
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" 
                    />
                  </div>
                  
                  <div className="flex-1 space-y-3">
                    <div className="flex flex-col md:flex-row md:items-start justify-between gap-2">
                      <div>
                        {provider.isDemo && (
                          <div className="mb-1.5 flex items-center gap-1.5 bg-amber-50 text-amber-800 text-[10px] font-bold px-2.5 py-0.5 rounded-full w-fit border border-amber-200">
                            <AlertTriangle size={12} /> DEMO PROFILE — NOT A REAL OR VERIFIED PROVIDER
                          </div>
                        )}
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="text-xl md:text-2xl font-bold text-slate-900 group-hover:text-blue-600 transition-colors">{provider.businessName}</h3>
                          {!provider.isDemo && provider.verificationStatus === 'verified' && <ShieldCheck size={20} className="text-blue-600" />}
                        </div>
                        <p className="text-slate-500 font-medium text-sm">{provider.name} · <span className="font-bold text-slate-900">{provider.category}</span></p>
                      </div>
                      <div className="flex items-center gap-1 bg-slate-900 text-white px-3 py-1 rounded-full text-sm font-bold w-fit shadow-md">
                        <Star size={14} fill="currentColor" />
                        <span>{provider.rating || 'New'}</span>
                      </div>
                    </div>

                    <p className="text-slate-600 text-xs md:text-sm line-clamp-2">{provider.bio || formatSkillsString(provider.skills)}</p>

                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4 py-3 border-y border-slate-50">
                      <div className="flex items-center gap-2 text-slate-600 text-xs md:text-sm font-medium">
                        <div className="w-7 h-7 rounded-lg bg-slate-100 flex items-center justify-center shrink-0">
                          <MapPin size={14} className="text-slate-500" />
                        </div>
                        <span>{provider.locality || 'Jaunpur'}</span>
                      </div>
                      <div className="flex items-center gap-2 text-slate-900 font-bold text-xs md:text-sm">
                        <div className="w-7 h-7 rounded-lg bg-emerald-50 flex items-center justify-center shrink-0">
                          <span className="text-emerald-700 text-[11px] font-black">₹</span>
                        </div>
                        <span>{cleanPrice(provider.price)}</span>
                      </div>
                      <div className="hidden md:flex items-center gap-2 text-slate-400 text-xs">
                        <span>{provider.reviews || 0} reviews</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-1">
                      <div className="text-xs text-slate-500 flex items-center gap-2">
                        <span className={`w-2 h-2 rounded-full ${provider.isDemo ? 'bg-amber-500' : 'bg-emerald-500'} animate-pulse`} />
                        <span className={`font-medium ${provider.isDemo ? 'text-amber-600' : 'text-emerald-600'}`}>
                          {provider.isDemo ? 'Demo Slot (Replace to activate)' : 'Available Today'}
                        </span>
                      </div>
                      <button className="btn-primary group-hover:bg-slate-800 transition-colors flex items-center gap-2 rounded-xl px-5 py-2 text-xs md:text-sm">
                        View Profile <ChevronRight size={16} />
                      </button>
                    </div>
                  </div>
                </Link>
              ))
            ) : (
              <div className="card p-16 text-center bg-slate-50 border-2 border-dashed border-slate-200 rounded-3xl">
                <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center mx-auto mb-6 shadow-sm">
                  <SearchIcon size={32} className="text-slate-300" />
                </div>
                <h3 className="text-2xl font-bold text-slate-900 mb-2">No providers found</h3>
                <p className="text-slate-500 mb-8 max-w-sm mx-auto">Try adjusting your filters or searching in a different area of Jaunpur.</p>
                <button 
                  onClick={clearFilters}
                  className="btn-primary"
                >
                  Clear All Filters
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default ServiceSearch;
